*   Allow skipping incineration of processed emails.

    This can be done by setting `config.action_mailbox.incinerate` to `false`.

    *Pratik Naik*

## Rails 6.0.0.beta1 (January 18, 2019) ##

*   Added to Rails.

    *DHH*
