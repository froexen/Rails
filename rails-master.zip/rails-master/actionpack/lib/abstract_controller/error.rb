# frozen_string_literal: true

module AbstractController
  class Error < StandardError #:nodoc:
  end
end
